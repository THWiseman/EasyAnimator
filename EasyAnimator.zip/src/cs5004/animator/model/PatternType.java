package cs5004.animator.model;

/**
 * The enum can represent each different type of pattern.
 */
public enum PatternType {
  SIZECHANGE, MOVEMENT, COLOR
}
